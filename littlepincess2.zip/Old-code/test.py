import discord
from discord.ext import commands
from core.classes import Cog_Extension
from replit import db
import pandas as pd

## 預先載入寫這邊
mapList = [
    "奧勒岡鄉間屋宅", "俱樂部會所", "杜思妥耶夫斯基咖啡館", "別墅", "木屋", "銀行", "主題樂園", "邊境", "摩天大樓"
]
valid_setting_types = ["列隊時間限制", '揪團冷卻時間']
team_name_id = {
    "隊伍一": 1,
    "隊伍二": 2,
}

#配對序列
gameNormalList = []
gameQuickList = []
gameEliteList = []

dfRoom = pd.DataFrame()


# <region> 加入配對
##確認序列中人數是否已滿
def CheckGameList(rankName):
    if gameNormalList.count() == 10 or gameEliteList.count(
    ) == 10 or gameQuickList.count() == 10:
        StartGame(rankName)


#開始遊戲
#這邊有請好心人幫我兜房間語法謝謝
def StartGame(rankName):
  if rankName =="Normal":
    gamelist = gameNormalList
  elif rankName == "Elite":
    gamelist = gameQuickList
  elif rankName =="Quick":
    gamelist = gameEliteList
    return 0


class TEST(Cog_Extension):

    ##加入配對主邏輯
    def JoinGame(rankName, userName):
        #把userName放進不同序列中
        if rankName == "Normal":
            gameNormalList.append(userName)
        elif rankName == "Elite":
            gameEliteList.append(userName)
        elif rankName == "Quick":
            gameQuickList.append(userName)
        CheckGameList(rankName)

    ##加入一般配對
    @commands.command()
    async def JoinNormalGame(self, ctx):
        rankName = "Normal"
        userName = ctx.message.author.name
        self.JoinGame(rankName, userName)
        await ctx.send("加入一般對戰序列")

    ##加入菁英配對
    @commands.command()
    async def JoinEliteGame(self, ctx):
        rankName = "Elite"
        userName = ctx.message.author.name
        self.JoinGame(rankName, userName)
        await ctx.send("加入菁英對戰序列")

    ##加入快速配對
    @commands.command()
    async def JoinQuickGame(self, ctx):
        rankName = "Quick"
        userName = ctx.message.author.name
        self.JoinGame(rankName, userName)
        await ctx.send("加入快速對戰序列")


# </region>

##離開配對

    @commands.command()
    async def LeaveGame(self, ctx):
        userName = ctx.message.author.name
        if userName in gameNormalList:
            gameNormalList.remove(userName)
        elif userName in gameEliteList:
            gameEliteList.remove(userName)
        elif userName in gameQuickList:
            gameQuickList.remove(userName)

    ##選取隊員
    @commands.command()
    async def PickMember(self, ctx):
        await ctx.send("Success")

    ##確認配對序列
    @commands.command()
    async def CheckGame(self, ctx):
        await ctx.send("Success")

    ##查詢排行榜
    @commands.command()
    async def CheckRankings(self, ctx):
        await ctx.send("Success")

    ##查詢個人戰績
    @commands.command()
    async def CheckPersonalDetail(self, ctx):
        await ctx.send("Success")

    ##標記揪團玩家(冷卻60分鐘)
    @commands.command()
    async def GetIntoGame(self, ctx):
        await ctx.send("Success")


async def setup(bot):
    await bot.add_cog(TEST(bot))

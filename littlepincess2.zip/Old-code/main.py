import discord
from discord.ext import commands
import requests
import json
import asyncio
import aiofiles
import random
import discord_slash
from discord_slash import SlashCommand, SlashCommandOptionType

from discord_slash.utils.manage_commands import create_choice, create_option

import r6_db
from r6_db import GameStateTypes

from datetime import datetime, timezone, timedelta
import math
import schedule
import traceback
import os.path

intents = discord.Intents.default()
intents.members = True

bot = commands.Bot(command_prefix='-', intents=intents)
bot.remove_command("help")
slash = SlashCommand(bot, sync_commands=True)
lock = asyncio.Lock()

manager_role_memtion = "<@&954690762170322944>"

bot.ticket_configs = {}
with open("TOKEN.txt", "r") as fr:
    TOKEN = fr.read()

db_path = 'bot.db'
setting_db = r6_db.SettingDatabase(db_path)
profile_db = r6_db.ProfileDatabase(db_path)
game_db = r6_db.GameDatabase(db_path)

admin_lock = True
if os.path.exists('./admin_lock_false'):
    admin_lock = False
print('admin lock =', admin_lock)

map_list = ["奧勒岡鄉間屋宅", "俱樂部會所", "杜思妥耶夫斯基咖啡館",
            "別墅", "木屋", "銀行", "主題樂園", "邊境", "摩天大樓"]
invite_region_name = '菁英'
region_names = [
    '一般',
    '快速',
    invite_region_name,
]

region_name_alias = {
    '快速': ['quick'],
    '菁英': ['elite'],
}
valid_role_types = ["註冊", "配對", "管理", "菁英", "揪團"]
valid_channel_types = ["公告", "賽果", "指令", "場次頻道類別"]
valid_setting_types = ["列隊時間限制", '揪團冷卻時間']
team_name_id = {
    "隊伍一": 1,
    "隊伍二": 2,
}
COLOR_INFO = 0x77bb41
COLOR_WARNING = 0xff2600


def json_load(path):
    with open(path, 'r', encoding="big5") as f:
        return json.load(f)


def json_dump(path, obj):
    with open(path, "w+", encoding="big5") as f:
        json.dump(obj, f, ensure_ascii=True)


async def sleep_msg_clear(msg, seconds):
    await asyncio.sleep(seconds)
    await msg.clear_reactions()
    setting_db.delete('leaderboard', str(msg.id), msg.guild.id)


@bot.event
async def on_ready():
    print("我準備好了")
    async with aiofiles.open("ticket_configs.txt", mode="a") as temp:
        pass
    async with aiofiles.open("ticket_configs.txt", mode="r") as file:
        lines = await file.readlines()
        for line in lines:
            data = line.split(" ")
            bot.ticket_configs[int(data[0])] = [int(
                data[1]), int(data[2]), int(data[3])]


def get_leaderboard_embed(guild_id, page, members_per_page=10):
    # page == -1 to set it to max_page
    # members[start_idx: end_idx]
    members = profile_db.get_members(guild_id)
    members = sorted(members, key=lambda item: item['score'], reverse=True)
    member_count = len(members)
    max_page = math.ceil(member_count / members_per_page)
    if page > max_page or page <= 0:
        page = max_page

    start_idx = (page - 1) * members_per_page
    end_idx = min(start_idx + members_per_page, member_count)
    # setting_db.save('leaderboard', message_id, page)

    names_str = ''
    for i in range(start_idx, end_idx):
        member = members[i]
        names_str += f"{i + 1} - <@!{member['member_id']}> 積分: {member['score']}\n"
    embed = discord.Embed(title=f"排行榜[{page}/{max_page}]")
    embed.add_field(name="玩家", value=names_str, inline=False)
    return embed, page


def get_mentions_from_member(members):
    mentions = []
    for member in members:
        if member:
            mentions.append(member.mention)
        else:
            mentions.append('無法取得資料')
    return mentions


def get_game_announce_embed(team_members, game_info, map_name, captain_ids):
    # map_name as argument to make it changeable
    game_id = game_info['game_id']
    team_mentions = []
    for i in range(len(team_members)):  # 2 for old, 3 for assign
        for idx, tm in enumerate(team_members[i]):
            if tm.id in captain_ids:
                team_members[i].pop(idx)
                team_members[i] = [tm] + team_members[i]
                break

    for i in range(len(team_members)):  # 2 for old, 3 for assign
        team_mentions.append(get_mentions_from_member(team_members[i]))

    reg_time = format_datetime(game_info['created_timestamp'])

    embed = discord.Embed(
        title=f"場次:#{game_id:04n} 現在已開始! [{game_info['region']}]",
        description=f"地圖: {map_name}\n創建時間: {reg_time}", color=0x34363d)
    embed.add_field(
        name="【隊伍一】", value='隊長: ' + '\n'.join(team_mentions[0]), inline=False)
    embed.add_field(
        name="【隊伍二】", value='隊長: ' + '\n'.join(team_mentions[1]), inline=False)
    if len(team_mentions) >= 3:
        to_assign_member_tags = [f'{idx + 1}. {mt}' for idx, mt in enumerate(team_mentions[2])]
        embed.add_field(name="【待分配】", value='\n'.join(to_assign_member_tags))
    tags = ['|'.join(tm) for tm in team_mentions]
    tag_str = '\n'.join(tags)
    return tag_str, embed


def get_game_assign_embed(team_members, game_info, map_name, captain_ids):
    # map_name as argument to make it changeable
    game_id = game_info['game_id']
    team_mentions = []
    for i in range(len(team_members)):  # 2 for old, 3 for assign
        for idx, tm in enumerate(team_members[i]):
            if tm.id in captain_ids:
                team_members[i].pop(idx)
                team_members[i] = [tm] + team_members[i]
                break

    for i in range(len(team_members)):  # 2 for old, 3 for assign
        team_mentions.append(get_mentions_from_member(team_members[i]))

    # reg_time = format_datetime(game_info['created_timestamp'])
    embed = discord.Embed(
        title=f"場次:#{game_id:04n} 分隊公告",
        description=f"地圖: {map_name}\n", color=0x34363d)
    embed.add_field(
        name="【隊伍一】", value='隊長: ' + '\n'.join(team_mentions[0]), inline=False)
    embed.add_field(
        name="【隊伍二】", value='隊長: ' + '\n'.join(team_mentions[1]), inline=False)
    if len(team_mentions) >= 3:
        to_assign_member_tags = [f'{idx + 1}. {mt}' for idx, mt in enumerate(team_mentions[2])]
        embed.add_field(name="【待分配】", value='\n'.join(to_assign_member_tags))
    tags = ['|'.join(tm) for tm in team_mentions]
    tag_str = '\n'.join(tags)
    return tag_str, embed


def update_leaderboard_page(guild_id, message_id, page):
    setting_db.save('leaderboard', message_id, page, guild_id)


async def update_member_nick(member, p, guild_owner=None):
    if member is None:
        return
    if member != guild_owner:
        nick = f"[{p['score']}] {p['name']}"
        await member.edit(nick=nick)


def format_datetime(dt):
    dt = dt.astimezone(timezone(timedelta(hours=8)))
    return dt.strftime("%Y年%m月%d日 %H點%M分%S秒")


# leaderboard
async def leaderboard(ctx):
    page = 1
    guild_id = ctx.guild.id
    async with lock:
        embed, page = get_leaderboard_embed(guild_id, page)
        msg = await ctx.reply(embed=embed)
        update_leaderboard_page(guild_id, msg.id, page)
        await msg.add_reaction("⏮")
        await msg.add_reaction("◀")
        await msg.add_reaction("▶")
        await msg.add_reaction("⏭")
        asyncio.get_event_loop().create_task(sleep_msg_clear(msg, 300))


bot.command()(leaderboard)
slash.slash(name='leaderboard', description='排行榜')(leaderboard)


# rename
async def rename(ctx, name: str):
    guild_id = ctx.guild.id
    member_id = ctx.author.id
    member_profile = profile_db.get_profile(member_id, guild_id)
    nick = f"[{member_profile['score']}] {name}"
    success = profile_db.edit_name(ctx.author.id, name, guild_id, check_duplicate=True)
    if success is not None:
        member = ctx.guild.get_member(ctx.author.id)
        if member is not None:
            await member.edit(nick=nick)
            embed = discord.Embed(
                title="暱稱更改成功", description=ctx.author.mention, color=0x77bb41)
            await ctx.reply(embed=embed)


bot.command()(rename)
slash.slash(name='rename', description='更改暱稱')(rename)


# register
async def register(ctx, name=None):
    async with lock:
        if name is None:
            embed = discord.Embed(title="【錯誤】-register <ID>", color=0xff2600)
            await ctx.reply(embed=embed)
            return

        member_id = ctx.author.id
        guild_id = ctx.guild.id
        member = ctx.guild.get_member(ctx.author.id)
        role_id = setting_db.getint('role', '註冊', guild_id)
        role = ctx.guild.get_role(role_id)

        member_profile = profile_db.get_profile(member_id, guild_id)
        if member_profile is None:
            dt_now = datetime.now()
            profile_db.add_profile(member_id, name, None, guild_id)
            profile_db.edit_profile(member_id, {'score': 1200}, guild_id)

            embed = discord.Embed(
                title="註冊成功✅", description=f"玩家:{member.mention}", color=0x96d35f)
            embed.set_thumbnail(url=member.avatar_url)
            reg_time = format_datetime(dt_now)
            embed.set_footer(text=reg_time)
            await ctx.reply(embed=embed)
            nick = f"[1200] {name}"
            if ctx.author != ctx.guild.owner:
                await member.edit(nick=nick)
            await member.add_roles(role)
        else:
            embed = discord.Embed(title="你已經註冊過了❌", color=0xff2600)
            await ctx.reply(embed=embed)


bot.command(aliases=["reg"])(register)
slash.slash(name="register", description="註冊")(register)


# profile
async def profile(ctx, player: discord.Member = None):
    member_id = player.id if player is not None else ctx.author.id
    guild_id = ctx.guild.id
    member_profile = profile_db.get_profile(member_id, guild_id)
    if member_profile is not None:
        member = ctx.guild.get_member(member_id)
        win = member_profile['win']
        lose = member_profile['lose']
        reg_time = format_datetime(member_profile['register_timestamp'])
        game = member_profile['game']
        score = member_profile['score']
        winning_streak = member_profile['winning_streak']
        embed = discord.Embed(
            title="戰績查詢", description=f"玩家:{member.mention}", color=0x00c7fc)
        embed.set_thumbnail(url=member.avatar_url)
        embed.add_field(
            name=f"積分: {score}\n勝場: {win}\n敗場: {lose}\n總場數: {game}\n目前連勝數: {winning_streak}",
            value=f"註冊於{reg_time}", inline=False)
        await ctx.reply(embed=embed)
    elif player is None:
        embed = discord.Embed(title="你尚未註冊❌", color=0xff2600)
        await ctx.reply(embed=embed)
    elif player is not None:
        embed = discord.Embed(title="此人尚未註冊❌", color=0xff2600)
        await ctx.reply(embed=embed)


bot.command(aliases=["p"])(profile)
slash.slash(name='profile', description='查看玩家資料')(profile)


def get_mentions_from_profiles(guild: discord.Guild, profiles):
    mentions = []
    for p in profiles:
        member = guild.get_member(p['member_id'])
        if member is not None:
            mentions.append(member.mention)
        else:
            mentions.append('無法取得資料')
    return mentions


def get_join_game_embed(guild: discord.Guild, game_id):
    # because of mention, this function need guild object
    # get discord embed from db
    guild_id = guild.id
    game_info, players = game_db.get_game_info(game_id, guild_id)
    region = game_info['region'] or '一般'
    embed = discord.Embed(
        title=f"✅ 成功加入配對 [{len(players)}/10] [{region}]", description=f"場次:#{game_id:04n}", color=0x34363d)

    mentions = get_mentions_from_profiles(guild, players)
    embed.add_field(
        name="玩家:", value='\n'.join(mentions), inline=False)
    return embed


def get_leave_game_embed(guild: discord.Guild, game_id):
    guild_id = guild.id
    game_info, players = game_db.get_game_info(game_id, guild_id)
    region = game_info['region'] or '一般'

    mentions = get_mentions_from_profiles(guild, players)
    player_mentions_str = '\n'.join(mentions) if len(mentions) > 0 else '未有玩家正在配對'
    embed = discord.Embed(
        title=f"⛔ 已離開配對 [{len(players)}/10] [{region}]", description=f"場次:#{game_id:04n}", color=0x34363d)
    embed.add_field(
        name="玩家:", value=player_mentions_str, inline=False)
    return embed


def get_queue_game_embed(guild: discord.Guild, game_id):
    guild_id = guild.id
    game_info, players = game_db.get_game_info(game_id, guild_id)
    region = game_info['region'] or '一般'

    mentions = get_mentions_from_profiles(guild, players)
    player_mentions_str = '\n'.join(mentions) if len(mentions) > 0 else '未有玩家正在配對'
    embed = discord.Embed(
        title=f"第二賽季 [{len(players)}/10] [{region}]", description=f"場次:#{game_id:04n}", color=0x34363d)
    embed.add_field(
        name="玩家:", value=player_mentions_str, inline=False)
    return embed


def convert_region_alias(region):
    if region is None:
        return region
    region = region.lower()
    if region in region_names:
        return region
    for k, v in region_name_alias.items():
        if type(v) == list:
            if region in v:
                return k
        elif region == v:
            return k
    return region


dedicated_role_id_attr = "dedicated_role_id"
dedicated_text_channel_id_attr = "dedicated_text_channel_id"
announce_message_id_attr = "announce_message_id"
dedicated_voice_channel_id1_attr = "dedicated_voice_channel_id1"
dedicated_voice_channel_id2_attr = "dedicated_voice_channel_id2"
dedicated_captain_id1_attr = "captain_id1"
dedicated_captain_id2_attr = "captain_id2"


# join
async def join(ctx, region=None):
    region = convert_region_alias(region)  # convert from alias
    if region is None:
        region = region_names[0]
    else:
        if region not in region_names:
            await ctx.reply(f"地區名稱錯誤 [{'|'.join(region_names)}]")
            return
    member_id = ctx.author.id
    guild_id = ctx.guild.id
    valid_channel = setting_db.getint('channel', '指令', guild_id)
    if ctx.channel.id != valid_channel:
        return
    guild = bot.get_guild(guild_id)

    async with lock:
        # Check if member queueing or playing
        member_profile = profile_db.get_profile(member_id, guild_id)
        if member_profile is None:
            return
        member_waiting_playing_games = game_db.get_members(member_id, states=[GameStateTypes.WAITING,
                                                                              GameStateTypes.ASSIGNING,
                                                                              GameStateTypes.PLAYING],
                                                           guild_id=guild_id)

        channel = bot.get_channel(setting_db.getint('channel', '公告', guild_id))
        role = ctx.guild.get_role(setting_db.getint('role', '配對', guild_id))
        dedicated_category = guild.get_channel(setting_db.getint('channel', '場次頻道類別', guild_id))
        dedicated_category: discord.CategoryChannel
        if dedicated_category is None:
            embed = discord.Embed(
                title="伺服器尚未設定創建頻道類別", color=COLOR_WARNING)
            await ctx.reply(embed=embed)
            return

        member = ctx.guild.get_member(ctx.author.id)
        if len(member_waiting_playing_games) == 0:
            # player is free to join
            waiting_games = game_db.get_games(states=GameStateTypes.WAITING, regions=region, guild_id=guild_id)
            if region == invite_region_name:
                # Additional invite role check
                invite_restrict_role = ctx.guild.get_role(setting_db.getint('role', '菁英', guild_id))
                if invite_restrict_role is None:
                    embed = discord.Embed(
                        title="伺服器尚未設定菁英身分組", color=COLOR_WARNING)
                    await ctx.reply(embed=embed)
                    return
                if invite_restrict_role not in member.roles:
                    embed = discord.Embed(
                        title="沒有菁英身分組", color=COLOR_WARNING)
                    await ctx.reply(embed=embed)
                    return

            if len(waiting_games) == 0:
                map_name = None
                game_id = game_db.new_game(map_name, region, None, guild_id)
            else:
                game_id = waiting_games[0]['game_id']

            game_db.add_member_to_game(game_id, member_id, None, guild_id)
            await member.add_roles(role)

            embed = get_join_game_embed(ctx.guild, game_id)
            msg = await ctx.reply(embed=embed)

            current_players = game_db.get_game_members_by_id(game_id, guild_id)

            if len(current_players) >= 10:
                embed.title = f"隊列已滿，正在分配隊伍......"
                embed.description = f"場次:#{game_id:04n}\n公告:{channel.mention}"
                embed.colour = 0x34363d
                await msg.edit(embed=embed)

                # teams = game_db.start_game(game_id, profile_db, guild_id)
                teams = game_db.start_assign_game(guild_id, game_id, profile_db)
                teams = game_db.get_game_teams(guild_id, game_id)

                game_info, players = game_db.get_game_info(game_id, guild_id)
                team_members = []
                for i in range(len(teams)):
                    team_members.append([])
                    for player in teams[i]:
                        member = ctx.guild.get_member(player['member_id'])
                        team_members[i].append(member)
                        if member:
                            await member.remove_roles(role)
                captain_ids = [teams[0][0]['member_id'], teams[1][0]['member_id']]
                tag_all, embed = get_game_announce_embed(team_members, game_info, '待定', captain_ids)
                announce_msg = await channel.send(content=tag_all, embed=embed)
                game_db.set_game_attr(guild_id, game_id, announce_message_id_attr, announce_msg.id)

                role_name = f'[{game_id} 場次玩家]'
                dedicated_role = await guild.create_role(name=role_name)
                overwrites = {
                    guild.default_role: discord.PermissionOverwrite(view_channel=False),
                    dedicated_role: discord.PermissionOverwrite(view_channel=True)
                }

                dedicated_text_channel = await dedicated_category.create_text_channel(f'[{game_id:04n}]-文字]',
                                                                                      overwrites=overwrites)
                dedicated_voice_channel1 = await dedicated_category.create_voice_channel(f'[{game_id:04n}-語音 - 隊伍 1]',
                                                                                         overwrites=overwrites,
                                                                                         user_limit=5)
                dedicated_voice_channel2 = await dedicated_category.create_voice_channel(f'[{game_id:04n}-語音 - 隊伍 2]',
                                                                                         overwrites=overwrites,
                                                                                         user_limit=5)
                game_db.set_game_attr(guild_id, game_id, dedicated_role_id_attr,
                                      str(dedicated_role.id))
                game_db.set_game_attr(guild_id, game_id, dedicated_text_channel_id_attr,
                                      str(dedicated_text_channel.id))
                game_db.set_game_attr(guild_id, game_id, dedicated_voice_channel_id1_attr,
                                      str(dedicated_voice_channel1.id))
                game_db.set_game_attr(guild_id, game_id, dedicated_voice_channel_id2_attr,
                                      str(dedicated_voice_channel2.id))

                captain_id1 = teams[0][0]['member_id']
                captain_id2 = teams[1][0]['member_id']
                game_db.set_game_attr(guild_id, game_id, dedicated_captain_id1_attr, captain_id1)
                game_db.set_game_attr(guild_id, game_id, dedicated_captain_id2_attr, captain_id2)

                tag_all, embed = get_game_assign_embed(team_members, game_info, '待定', (captain_id1, captain_id2))

                for i in range(len(team_members)):
                    for team_member in team_members[i]:
                        team_member: discord.Member
                        if team_member is not None:
                            await team_member.add_roles(dedicated_role)
                mes = await dedicated_text_channel.send(f'{dedicated_role.mention}', embed=embed)

        else:
            embed = discord.Embed(title="你已加入配對或開始了❌", color=0xff2600)
            await ctx.reply(embed=embed)


bot.command(aliases=["j"])(join)
slash.slash(name='join', description='加入配對',
            options=[
                create_option(
                    name='region',
                    description='選擇要加入的地區',
                    required=False,
                    option_type=SlashCommandOptionType.STRING,
                    choices=[create_choice(name=region_name, value=region_name) for region_name in region_names]
                )
            ])(join)


async def pick(ctx, member_idx: int):
    member_id = ctx.author.id
    guild_id = ctx.guild.id
    member_assigning_games = game_db.get_members(member_id, states=[GameStateTypes.ASSIGNING],
                                                 guild_id=guild_id)
    if len(member_assigning_games) < 1:
        return
    game_id = member_assigning_games[0]['game_id']
    game_info, players = game_db.get_game_info(game_id, guild_id)
    author_game_info = None
    for player in players:
        if player['member_id'] == ctx.author.id:
            author_game_info = player

    game_text_channel_id = game_db.get_game_attr_int(guild_id, game_id, dedicated_text_channel_id_attr)
    if ctx.channel.id != game_text_channel_id:
        return

    game_captain_id1 = game_db.get_game_attr_int(guild_id, game_id, dedicated_captain_id1_attr)
    game_captain_id2 = game_db.get_game_attr_int(guild_id, game_id, dedicated_captain_id2_attr)

    teams = game_db.get_game_teams(guild_id, game_id)

    assigning_team = 1 if len(teams[0]) <= len(teams[1]) else 2
    assigning_captain_id = game_captain_id1 if assigning_team == 1 else game_captain_id2
    if ctx.author.id not in [game_captain_id1, game_captain_id2]:
        embed = discord.Embed(title="【 ❌ 你無權使用此指令】", color=COLOR_WARNING)
        await ctx.reply(embed=embed)
        return
    if ctx.author.id != assigning_captain_id:
        embed = discord.Embed(title="【 ❌ 請等待對方選擇隊員】", color=COLOR_WARNING)
        await ctx.reply(embed=embed)
        return
    player_pool = teams[2]
    if member_idx > len(player_pool) or member_idx < 1:
        embed = discord.Embed(title="【 ❌ 編號錯誤】", color=COLOR_WARNING)
        await ctx.reply(embed=embed)
        return

    to_assign_player = player_pool.pop(member_idx - 1)
    teams[assigning_team - 1].append(to_assign_player)
    game_db.set_members_team(game_id, [to_assign_player], assigning_team, guild_id)
    teams = game_db.get_game_teams(guild_id, game_id)
    team_members = []
    for i in range(len(teams)):
        team_members.append([])
        for player in teams[i]:
            member = ctx.guild.get_member(player['member_id'])
            team_members[i].append(member)
    if len(team_members[2]) == 0:
        team_members.pop(2)
        map_name = game_info['map']
        game_db.set_game_state(game_id, GameStateTypes.PLAYING, guild_id)
        announce_channel = bot.get_channel(setting_db.getint('channel', '公告', guild_id))
        game_announce_message_id = game_db.get_game_attr_int(guild_id, game_id, announce_message_id_attr)
        game_announce_message = await announce_channel.fetch_message(game_announce_message_id)
        tag_all, embed = get_game_announce_embed(team_members, game_info, map_name, (game_captain_id1, game_captain_id2))
        game_announce_message: discord.Message
        await game_announce_message.edit(content=tag_all, embed=embed)
    else:
        map_name = '待定'
    tag_all, embed = get_game_assign_embed(team_members, game_info, map_name, (game_captain_id1, game_captain_id2))
    await ctx.reply(embed=embed)


bot.command()(pick)
slash.slash(name='pick', description='選擇隊員',
            options=[
                create_option(
                    name='member_idx',
                    description='選擇隊員的編號',
                    required=True,
                    option_type=SlashCommandOptionType.INTEGER,
                )
            ])(pick)


# leave
async def leave(ctx):
    async with lock:
        guild = ctx.guild
        guild_id = guild.id
        member_id = ctx.author.id
        valid_channel = bot.get_channel(setting_db.getint('channel', '指令', guild_id))
        if ctx.channel != valid_channel:
            return

        member = ctx.guild.get_member(member_id)
        role = ctx.guild.get_role(setting_db.getint('role', '配對', guild_id))

        member_waiting_games = game_db.get_member_waiting_game(member_id, guild_id)
        for game_info in member_waiting_games:
            game_id = game_info['game_id']
            game_db.remove_member_from_game(game_id, member_id, guild_id)
            await member.remove_roles(role)
            embed = get_leave_game_embed(guild, game_id)
            await ctx.reply(embed=embed)


bot.command(aliases=["l"])(leave)
slash.slash(name='leave', description='離開配對')(leave)


# queue
async def _queue(ctx, region: str):
    if region is not None:
        region = convert_region_alias(region)  # convert from alias
    else:
        region = region_names[0]

    if region is not None and region not in region_names:
        await ctx.reply(f"地區名稱錯誤 [{'|'.join(region_names)}]")
        return
    guild = ctx.guild
    guild_id = guild.id
    valid_channel = bot.get_channel(setting_db.getint('channel', '指令', guild_id))
    if ctx.channel != valid_channel:
        return
    async with lock:
        waiting_games = game_db.get_games(states=GameStateTypes.WAITING, regions=region, guild_id=guild_id)
        if len(waiting_games) > 0:
            for g in waiting_games:
                game_id = g['game_id']
                embed = get_queue_game_embed(guild, game_id)
                await ctx.reply(embed=embed)
        else:
            embed = discord.Embed(title=f"沒有玩家正在配對❌ [{region or '一般'}]", color=0xff2600)
            await ctx.reply(embed=embed)


@bot.command(aliases=["q"])
async def queue(ctx, region=None):
    await _queue(ctx, region)


@slash.slash(name="queue", description="查看配對", options=[
    create_option(
        name='region',
        description='選擇要查詢的地區',
        required=False,
        option_type=SlashCommandOptionType.STRING,
        choices=[create_choice(name=region_name, value=region_name) for region_name in region_names]
    )
])
async def queue(ctx, region=None):
    await _queue(ctx, region)


# admin command


# game
async def _game(ctx, game_id: int, winner_team: str):
    async with lock:
        guild = ctx.guild
        guild_id = guild.id
        channel = bot.get_channel(setting_db.getint('channel', '賽果', guild_id))
        admin_role = ctx.guild.get_role(setting_db.getint('role', '管理', guild_id))
        member = ctx.guild.get_member(ctx.author.id)
        if admin_lock and admin_role not in member.roles:
            return
        game_info = game_db.get_game_by_id(game_id, guild_id)
        if game_info is None:
            embed = discord.Embed(title=f"【錯誤】- `[{game_id:04n}]` 場次不存在", color=0xff2600)
            await ctx.reply(embed=embed)
            return
        if game_info['state'] != GameStateTypes.PLAYING:
            if game_info['state'] == GameStateTypes.WAITING:
                embed = discord.Embed(title=f"【錯誤】- `[{game_id:04n}]` 尚未開始", color=0xff2600)
            elif game_info['state'] == GameStateTypes.FINISHED:
                embed = discord.Embed(title=f"【錯誤】- `[{game_id:04n}]` 已經結算", color=0xff2600)
            else:
                embed = discord.Embed(title=f"【錯誤】- `[{game_id:04n}]` {game_info['state']}", color=0xff2600)
            await ctx.reply(embed=embed)
            return

        winner_team_id = team_name_id[winner_team]
        embed = discord.Embed(title="統計中請稍候......", color=0x34363d)
        msg = await channel.send(embed=embed)
        embed = discord.Embed(
            title=f"勝利隊伍:【{winner_team}】🏆", description=f"場次: #{game_id:04n}", color=0xf5ec00)

        game_db.finish_game(game_id, guild_id)
        for team_name, team_id in team_name_id.items():
            team_members = game_db.get_game_members_by_id(game_id, guild_id, team_id)
            mentions = []

            for tm in team_members:
                member_id = tm['member_id']
                member = guild.get_member(member_id)
                p = profile_db.get_profile(member_id, guild_id)
                if member:
                    mentions.append(member.mention)
                else:
                    mentions.append('無法取得資料')
                    continue
                if team_id == winner_team_id:
                    # win
                    if game_info['region'] == '快速':
                        win_score = 6
                        new_winning_streak = p['winning_streak']
                    else:
                        win_score = 11
                        new_winning_streak = p['winning_streak'] + 1

                    new_profile = {
                        'score': max(p['score'] + win_score, 0),
                        'win': p['win'] + 1,
                        'game': p['game'] + 1,
                        'winning_streak': new_winning_streak
                    }
                    if new_profile['winning_streak'] >= 5:
                        new_profile['score'] += 5
                else:
                    # loss
                    if game_info['region'] == '快速':
                        loss_score = 5
                        new_winning_streak = p['winning_streak']
                    else:
                        loss_score = 9
                        new_winning_streak = 0
                    new_profile = {
                        'score': max(p['score'] - loss_score, 0),
                        'lose': p['lose'] + 1,
                        'game': p['game'] + 1,
                        'winning_streak': new_winning_streak
                    }
                profile_db.edit_profile(member_id, new_profile, guild_id)
                new_profile = profile_db.get_profile(member_id, guild_id)
                await update_member_nick(member, new_profile, ctx.guild.owner)

            mention_str = '\n'.join(mentions) if mentions else '沒有玩家'
            if team_id == winner_team_id:
                embed.add_field(name=f"🥇【{team_name}】", value=mention_str, inline=False)
            else:
                embed.add_field(name=f"【{team_name}】", value=mention_str, inline=False)

        await msg.edit(embed=embed)
        game_role_id = game_db.get_game_attr_int(guild_id, game_id, dedicated_role_id_attr)
        game_text_channel_id = game_db.get_game_attr_int(guild_id, game_id, dedicated_text_channel_id_attr)
        game_voice_channel1_id = game_db.get_game_attr_int(guild_id, game_id, dedicated_voice_channel_id1_attr)
        game_voice_channel2_id = game_db.get_game_attr_int(guild_id, game_id, dedicated_voice_channel_id2_attr)
        await guild.get_channel(game_text_channel_id).delete()
        await guild.get_channel(game_voice_channel1_id).delete()
        await guild.get_channel(game_voice_channel2_id).delete()
        await guild.get_role(game_role_id).delete()


@bot.command()
@commands.has_permissions(administrator=admin_lock)
async def game(ctx, game_id: int, team: str):
    await _game(ctx, game_id, team)


@slash.slash(name="game", description="結算成績",
             options=[
                 create_option(
                     name='game_id',
                     description='場次',
                     required=True,
                     option_type=SlashCommandOptionType.INTEGER,
                 ),
                 create_option(
                     name='team',
                     description='勝利隊伍',
                     required=True,
                     option_type=SlashCommandOptionType.STRING,
                     choices=[create_choice(name=team_name, value=team_name) for team_name in
                              team_name_id.keys()]
                 )])
@commands.has_permissions(administrator=admin_lock)
async def game(ctx, game_id: int, team: str):
    await _game(ctx, game_id, team)


# setchannel
async def _setchannel(ctx, channel_type, channel: discord.TextChannel):
    guild_id = ctx.guild.id

    if channel_type in valid_channel_types:
        setting_db.save('channel', channel_type, channel.id, guild_id)

        embed = discord.Embed(title=f"將{channel_type}頻道設定為",
                              description=channel.mention, color=0x77bb41)
        await ctx.reply(embed=embed)


@bot.command()
@commands.has_permissions(administrator=admin_lock)
async def setchannel(ctx, channel_type, channel: discord.TextChannel):
    await _setchannel(ctx, channel_type, channel)


@slash.slash(name='setchannel', description="設定頻道",
             options=[
                 create_option(
                     name='channel_type',
                     description='類別',
                     required=True,
                     option_type=SlashCommandOptionType.STRING,
                     choices=[create_choice(name=channel_type, value=channel_type) for channel_type in
                              valid_channel_types]
                 ),
                 create_option(
                     name='channel',
                     description='頻道',
                     required=True,
                     option_type=SlashCommandOptionType.CHANNEL
                 )])
@commands.has_permissions(administrator=admin_lock)
async def setchannel(ctx, channel_type, channel: discord.TextChannel):
    await _setchannel(ctx, channel_type, channel)


# set_role
async def _setrole(ctx, role_type: str, role: discord.Role):
    guild_id = ctx.guild.id
    if role_type in valid_role_types:
        setting_db.save('role', role_type, str(role.id), guild_id)
        embed = discord.Embed(
            title=f"將{role_type}身份組設定為", description=role.mention, color=0x77bb41)
        await ctx.reply(embed=embed)


@bot.command()
@commands.has_permissions(administrator=admin_lock)
async def setrole(ctx, role_type: str, role: discord.Role):
    await _setrole(ctx, role_type, role)


@slash.slash(name='setrole', description='設定身份組',
             options=[
                 create_option(
                     name='role_type',
                     description='類別',
                     required=True,
                     option_type=SlashCommandOptionType.STRING,
                     choices=[create_choice(name=role_type, value=role_type) for role_type in valid_role_types]
                 ),
                 create_option(
                     name='role',
                     description='身分組',
                     required=True,
                     option_type=SlashCommandOptionType.ROLE
                 )])
@commands.has_permissions(administrator=admin_lock)
async def setrole(ctx, role_type: str, role: discord.Role):
    await _setrole(ctx, role_type, role)


# set_setting
async def _setval(ctx, setting_type: str, setting_value: str):
    guild_id = ctx.guild.id
    if setting_type in valid_setting_types:
        setting_db.save('setting', setting_type, setting_value, guild_id)
        embed = discord.Embed(
            title=f"將{setting_type}設定為", description=setting_value, color=0x77bb41)
        await ctx.reply(embed=embed)


@bot.command()
@commands.has_permissions(administrator=admin_lock)
async def setval(ctx, setting_type: str, setting_value: str):
    await _setval(ctx, setting_type, setting_value)


@slash.slash(name='setval', description='設定參數',
             options=[
                 create_option(
                     name='setting_type',
                     description='類別',
                     required=True,
                     option_type=SlashCommandOptionType.STRING,
                     choices=[create_choice(name=setting_type, value=setting_type) for setting_type in
                              valid_setting_types]
                 ),
                 create_option(
                     name='setting_value',
                     description='參數',
                     required=True,
                     option_type=SlashCommandOptionType.STRING
                 )])
@commands.has_permissions(administrator=admin_lock)
async def setval(ctx, setting_type: str, setting_value: str):
    await _setval(ctx, setting_type, setting_value)


# raid
async def _raid(ctx):
    guild_id = ctx.guild.id
    valid_channel_id = setting_db.getint('channel', '指令', guild_id)
    # valid_channel = bot.get_channel(setting_db.getint('channel', '指令', guild_id))
    if ctx.channel.id != valid_channel_id:
        return
    last_used_time = setting_db.get('setting', '揪團使用時間', guild_id=guild_id)
    raid_cooldown_minutes = setting_db.getint('setting', '揪團冷卻時間', guild_id=guild_id)

    if last_used_time is not None:
        last_used_time = datetime.strptime(last_used_time, '%Y年%m月%d日 %H點%M分%S秒')
        cooldown = datetime.now() - last_used_time
        if raid_cooldown_minutes is not None:
            raid_time_delta = timedelta(minutes=raid_cooldown_minutes)
            if cooldown < raid_time_delta:
                time_diff = raid_time_delta - cooldown
                await ctx.reply(f'🔕 揪團指令冷卻中（剩餘{int(time_diff.total_seconds() // 60)}分'
                                f'{int(time_diff.total_seconds() % 60)}秒）')
                return
    mention_role_id = setting_db.getint('role', '揪團', guild_id=guild_id)
    # embed = discord.Embed(title=f"🔔 <@{ctx.author.id}> 使用了揪團指令。", color=0x77bb41)
    message = f"🔔 <@&{mention_role_id}> <@{ctx.author.id}> 使用了揪團指令。"
    setting_db.save('setting', '揪團使用時間', datetime.now().strftime('%Y年%m月%d日 %H點%M分%S秒'), guild_id=guild_id)
    await ctx.send(message)


@bot.command()
async def raid(ctx):
    await _raid(ctx)


# @slash.slash(name='raid', description='揪團提醒')
# async def raid(ctx):
#     await _raid(ctx)


async def _cancel(ctx, game_id: int):
    async with lock:
        guild = ctx.guild
        guild_id = guild.id
        member = ctx.guild.get_member(ctx.author.id)
        role_manager = ctx.guild.get_role(setting_db.getint('role', '管理', guild_id))
        # admin check, but actually this command already requires admin.
        if admin_lock and role_manager not in member.roles:
            return
        role_match = ctx.guild.get_role(setting_db.getint('role', '配對', guild_id))
        game_info = game_db.get_game_by_id(game_id, guild_id)
        if game_info is None:
            embed = discord.Embed(title=f"沒有此場次❌ [{game_id:04n}]", color=0xff2600)
            await ctx.reply(embed=embed)
            return

        if game_info['state'] not in (GameStateTypes.WAITING, GameStateTypes.PLAYING,
                                      GameStateTypes.ASSIGNING):
            embed = discord.Embed(title=f"【錯誤】- `[{game_id:04n}]` {game_info['state']} 無法被取消", color=0xff2600)
            await ctx.reply(embed=embed)
            return

        removed_members = game_db.remove_game(game_id, guild_id)
        for m in removed_members:
            member_id = m['member_id']
            member = guild.get_member(member_id)
            if member is not None:
                await member.remove_roles(role_match)

        game_role_id = game_db.get_game_attr_int(guild_id, game_id, dedicated_role_id_attr)
        game_text_channel_id = game_db.get_game_attr_int(guild_id, game_id, dedicated_text_channel_id_attr)
        game_voice_channel1_id = game_db.get_game_attr_int(guild_id, game_id, dedicated_voice_channel_id1_attr)
        game_voice_channel2_id = game_db.get_game_attr_int(guild_id, game_id, dedicated_voice_channel_id2_attr)
        if game_text_channel_id:
            await guild.get_channel(game_text_channel_id).delete()
        if game_voice_channel1_id:
            await guild.get_channel(game_voice_channel1_id).delete()
        if game_voice_channel2_id:
            await guild.get_channel(game_voice_channel2_id).delete()
        if game_role_id:
            await guild.get_role(game_role_id).delete()

        embed = discord.Embed(
            title=f"已刪除", description=f"場次:#{game_id:04n}", color=0x34363d)
        await ctx.reply(embed=embed)


@bot.command()
@commands.has_permissions(administrator=admin_lock)
async def cancel(ctx, game_id: int):
    await _cancel(ctx, game_id)


# slash command
@slash.slash(name="cancel", description="刪除場次")
@commands.has_permissions(administrator=admin_lock)
async def cancel(ctx, game_id: int):
    await _cancel(ctx, game_id)


@slash.slash(name='reset', description="重置玩家積分")
@commands.has_permissions(administrator=admin_lock)
async def reset(ctx, member: discord.Member):
    guild_id = ctx.guild.id
    member_id = member.id
    p = profile_db.get_profile(member_id, guild_id)
    if p is not None:
        profile_db.reset_season_data(member_id, guild_id)
        p = profile_db.get_profile(member_id, guild_id)
        embed = discord.Embed(
            title="已重置玩家積分", description=member.mention, color=0x77bb41)
        await ctx.send(embed=embed)
        nick = f"[{p['score']}] {p['name']}"
        await member.edit(nick=nick)
    else:
        embed = discord.Embed(title="此玩家未註冊", color=0xff2600)
        await ctx.send(embed=embed)


async def _resetall(ctx):
    embed = discord.Embed(title="確定重置所有玩家積分? [y]", color=0x77bb41)
    await ctx.reply(embed=embed)
    msg = await bot.wait_for('message', check=lambda message: message.author == ctx.author)
    if msg.content.lower() != 'y':
        embed = discord.Embed(title="已取消", color=0x77bb41)
        await ctx.reply(embed=embed)
        return
    embed = discord.Embed(title="正在重置所有玩家積分", color=0x77bb41)
    msg = await ctx.send(embed=embed)

    guild_id = ctx.guild.id
    profile_db.reset_all_season_data(guild_id)
    profiles = profile_db.get_members(guild_id)
    for p in profiles:
        member_id = p['member_id']
        member = ctx.guild.get_member(member_id)
        if member is None:
            continue
        if member != ctx.guild.owner:
            nick = f"[{p['score']}] {p['name']}"
            await member.edit(nick=nick)
    embed = discord.Embed(title="已重置所有玩家積分", color=0x77bb41)
    await msg.edit(embed=embed)


@slash.slash(name='resetall', description="重置所有玩家積分")
@commands.has_permissions(administrator=admin_lock)
async def resetall(ctx):
    await _resetall(ctx)


@bot.command(name='resetall', description="重置所有玩家積分")
@commands.has_permissions(administrator=admin_lock)
async def resetall(ctx):
    await _resetall(ctx)


# async def _testing9(ctx, region: str = None):
#     print('testing9', region)
#     game_db.testing_add_9_game(region, ctx.guild.id)
#
#
# @bot.command(name='testing9', description="add game with 9 players")
# @commands.has_permissions(administrator=admin_lock)
# async def testing9(ctx, region: str = None):
#     await _testing9(ctx, region)


# event
@bot.event
async def on_raw_reaction_add(payload):
    guild_id = payload.guild_id
    message_id = payload.message_id
    channel = bot.get_channel(payload.channel_id)
    message = await channel.fetch_message(message_id)
    user = bot.get_user(payload.user_id)
    page = setting_db.getint('leaderboard', str(message_id), guild_id)
    if page is not None and user != bot.user:
        await message.remove_reaction(payload.emoji, user)
        if str(payload.emoji) == "⏮":
            page = 1
        elif str(payload.emoji) == "⏭":
            page = -1
        elif str(payload.emoji) == "◀" and page >= 1:
            page -= 1
        elif str(payload.emoji) == "▶":
            page += 1
        embed, page = get_leaderboard_embed(guild_id, page)  # return the embed and corrected page
        update_leaderboard_page(guild_id, str(message_id), page)
        await message.edit(embed=embed)

    if payload.member.id != bot.user.id and str(payload.emoji) == u"📩":
        msg_id, channel_id, category_id = bot.ticket_configs[payload.guild_id]

        if payload.message_id == msg_id:
            guild = bot.get_guild(payload.guild_id)

            for category in guild.categories:
                if category.id == category_id:
                    break

            channel = guild.get_channel(channel_id)

            with open("ticket.txt", "r") as r:
                ticket_num = int(r.read())

            ticket_channel = await category.create_text_channel(f"檢舉案件-{ticket_num}",
                                                                topic=f"A ticket for {payload.member.display_name}.",
                                                                permission_synced=True)
            ticket_num += 1
            ticket_num = str(ticket_num)

            with open("ticket.txt", "w") as w:
                w.writelines(ticket_num)

            await ticket_channel.set_permissions(payload.member, read_messages=True, send_messages=True)

            message = await channel.fetch_message(msg_id)
            await message.remove_reaction(payload.emoji, payload.member)

            await ticket_channel.send(
                f"{payload.member.mention} 你已成功開啟檢舉案件，請在此頻道完整說明事情始末並附上證據。\n{manager_role_memtion}將會盡快回復此案件，完整的證據說明可以增加處理效率。")


@bot.command()
@commands.has_permissions(administrator=True)
async def ticket(ctx, msg: discord.Message = None, category: discord.CategoryChannel = None):
    if msg is None or category is None:
        await ctx.channel.send("Failed to configure the ticket as an argument was not given or was invalid.")
        return

    bot.ticket_configs[ctx.guild.id] = [
        msg.id, msg.channel.id, category.id]  # this resets the configuration

    async with aiofiles.open("ticket_configs.txt", mode="r") as file:
        ticket_data = await file.readlines()

    async with aiofiles.open("ticket_configs.txt", mode="w") as file:
        await file.write(f"{ctx.guild.id} {msg.id} {msg.channel.id} {category.id}\n")

        for line in ticket_data:
            if int(line.split(" ")[0]) != ctx.guild.id:
                await file.write(line)

    await msg.add_reaction(u"📩")
    await ctx.channel.send("Successfully configured the ticket system.")


@slash.slash(name="score", description="修改分數")
@commands.has_permissions(administrator=admin_lock)
async def score(ctx, member: discord.Member, sym: str, num: str):
    num = int(num)
    guild_id = ctx.guild.id
    member_id = member.id
    member = ctx.guild.get_member(member_id)

    p = profile_db.get_profile(member_id, guild_id)
    if p is None:
        await ctx.send("no user")
        return
    from_score = p['score']
    new_profile = {
        'score': p['score']
    }
    if sym == "+":
        new_profile['score'] += num
    elif sym == "-":
        new_profile['score'] -= num
    profile_db.edit_profile(member_id, new_profile, guild_id)
    p = profile_db.get_profile(member_id, guild_id)
    await update_member_nick(member, p, ctx.guild.owner)
    await ctx.send(f"success, `[{from_score}]` -> `[{p['score']}]`")


@slash.slash(name="offTicket", description="清除權限")
async def offTicket(ctx, channel: discord.TextChannel, user: discord.Member):
    await channel.set_permissions(user, overwrite=None)
    await ctx.reply("清除成功")


async def schedule_clear_game_member():
    gs = setting_db.get_all_guild('setting', '列隊時間限制')
    time_now = datetime.now()
    for guild_id, value in gs:
        guild_id = int(guild_id)
        guild = bot.get_guild(guild_id)
        queue_role_id = setting_db.getint('role', '配對', guild_id)
        if queue_role_id is not None:
            queue_role = guild.get_role(queue_role_id)
        else:
            queue_role = None
        value = int(value)
        time_interval = timedelta(minutes=value)
        valid_channel_id = setting_db.getint('channel', '指令', guild_id)
        valid_channel = guild.get_channel(valid_channel_id)
        games = game_db.get_games(states=GameStateTypes.WAITING, guild_id=guild_id)
        for g in games:
            game_info, players = game_db.get_game_info(g['game_id'], guild_id=guild_id)
            game_id = game_info['game_id']
            for p in players:
                mid = p['member_id']
                member = guild.get_member(mid)
                waited_time = time_now - p['add_time']
                if waited_time >= time_interval:
                    game_db.remove_member_from_game(game_id, mid, guild_id=guild_id)
                    await member.remove_roles(queue_role)
                    await valid_channel.send(f'⛔ [{len(players) - 1}/10] <@{mid}> 因等待時間過久而離開隊列。')


async def crontab_loop():
    while True:
        try:
            schedule.run_pending()
            await asyncio.sleep(15)
        except Exception as e:
            traceback.print_exc()
            await asyncio.sleep(5)


if __name__ == '__main__':
    schedule.every(1).minutes.do(lambda: bot.loop.create_task(schedule_clear_game_member()))
    bot.loop.create_task(crontab_loop())
    bot.run(TOKEN)
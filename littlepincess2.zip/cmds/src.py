import discord
from discord.ext import commands
from core.classes import Cog_Extension
import pygsheets
import pandas as pd
import json

with open('setting.json', "r", encoding="utf8") as file:
    data = json.load(file)

#API金鑰
gc = pygsheets.authorize(service_file="API_Key.json")
#取得Google Sheet ID
id = data['sheetID']

#報名表單
WeekSignin = gc.open_by_url(
    f'https://docs.google.com/spreadsheets/d/{id}/edit?usp=sharing')

#驗證表單
Verification = gc.open_by_url(
    'https://docs.google.com/spreadsheets/d/127wGSh0rsGMyIKld4bRyF5ckOAAoKDXYIIIxnptrK2U/edit?usp=sharing'
)

#選取by順序
Vaild = WeekSignin[0]  #Vaild
TW = WeekSignin[1]  #TW
EN = WeekSignin[2]  #EN
Veri = Verification[0]  #Verification
Veri_TW = Verification[1]  #Verification_TW
Veri_EN = Verification[2]  #Verification_EN


class SRC(Cog_Extension):

    #SRC Server Only
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def comlist(self, ctx):
        Embed = discord.Embed(title="小公主_BOT",
                              description="是一個可愛的坎特貝雷的小公主\n目前擁有指令如下",
                              color=0xf7ff8a)
        Embed.set_author(
            name="小公主",
            icon_url=
            "https://cdn.discordapp.com/attachments/759118803396984853/866698612208697354/6c12be5f091dbf1329436bafc73f47afd2ded3cf.jpg"
        )
        Embed.set_thumbnail(url="https://i.imgur.com/lyjRujt.gif")
        Embed.add_field(name="%ping", value="顯示機器人延遲", inline=False)
        Embed.add_field(name="%clean {數字}", value="根據你輸入的數字刪除文字", inline=False)
        Embed.add_field(name="%createrole {RoleName}",
                        value="根據你輸入的文字創建一個預設類型身分組",
                        inline=False)
        Embed.add_field(name="%addrole {RoleName} {User#1234}",
                        value="根據你輸入的文字給定使用者該身分組",
                        inline=False)
        Embed.add_field(name="%SetSheetID {SheetID}",
                        value="設定Google Sheet(更新完後記得輸入 %reload src)",
                        inline=False)
        Embed.add_field(name="%CheckSheet",
                        value="檢查目前所設定的Sheet",
                        inline=False)
        Embed.add_field(name="%SubmitTeam {數字}",
                        value="給定行數會自動去抓資料給定選手身分組(抓TW表單)",
                        inline=False)
        Embed.add_field(name="%SubmitTeamEn {數字}",
                        value="給定行數會自動去抓資料給定選手身分組(抓En表單)",
                        inline=False)
        Embed.add_field(name="", value="", inline=False)
        Embed.add_field(
            name="使用說明",
            value=
            "先輸入SetSheetID指令設定好SheetID後，調用SubmitTeam指令且輸入行數，Bot就會自動完成創建身分組和給身組的工作",
            inline=False)
        await ctx.send(embed=Embed)

    ##創建身分組(預設類型身分組)
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def createrole(self, ctx, args=None):
        if (args == None):
            await ctx.send("Enter Role Name Plz!")
            return
        await ctx.guild.create_role(name=args, colour=0xffffff)
        await ctx.send("Create Role Success")

    ##給定帳號身分組(args1=role_name, args2=user)
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def addrole(self, ctx, args1, args2):
        user = ctx.guild.get_member_named(args2)
        role = discord.utils.get(ctx.guild.roles, name=args1)
        await user.add_roles(role)
        await ctx.send("Add Role Success")

    ## 選手身分驗證TW表單
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def verifyTW(self, ctx, args):
        rng = Veri_TW.get_values(f'B{args}', f'F{args}',
                                 returnas='range')  #抓取選手驗證資料
        item = rng.cells[0]
        DCName = item[1].value
        IsinVeri = Veri.find(DCName)  #取得Verification表單
        IsinDC = ctx.guild.get_member_named(DCName)  #確認是否在SRC伺服器
        Verified = discord.utils.get(ctx.guild.roles, name=data['Verified'])
        UnVerified = discord.utils.get(ctx.guild.roles,
                                       name=data['UnVerified'])

        if len(IsinVeri) != 0:
            await ctx.send(f"{DCName} has been verify already!")

        if IsinDC == None:  #確認是否在SRC伺服器
            #print("Isn't in DC")
            await ctx.send(f"{DCName} isn't in DC")

        else:
            index = ['B', 'C', 'D', 'E', 'F']  #存選手驗證資料欄位
            values = Veri.get_all_values()
            df = pd.DataFrame(values[0:], columns=values[0])
            end_row = df[df["Discord ID"].isin([""])].head(1).index.values[0]
            row = end_row + 1  #最後一欄
            #寫入隊伍資訊
            for i in range(0, 5):
                Veri.update_value(f'{index[i]}{row}',
                                  f'{item[i].value}')  # update the values

            await IsinDC.delete_roles(UnVerified)
            await IsinDC.add_roles(Verified)
            await ctx.send(f"{DCName} verify Success!")

    ## 選手身分驗證EN表單
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def verifyEN(self, ctx, args):
        rng = Veri_EN.get_values(f'B{args}', f'F{args}',
                                 returnas='range')  #抓取選手驗證資料
        item = rng.cells[0]
        DCName = item[1].value
        IsinVeri = Veri.find(DCName)  #取得Verification表單
        IsinDC = ctx.guild.get_member_named(DCName)  #確認是否在SRC伺服器
        Verified = discord.utils.get(ctx.guild.roles, name=data['Verified'])
        UnVerified = discord.utils.get(ctx.guild.roles,
                                       name=data['UnVerified'])

        if len(IsinVeri) != 0:
            await ctx.send(f"{DCName} has been verify already!")

        if IsinDC == None:  #確認是否在SRC伺服器
            #print("Isn't in DC")
            await ctx.send(f"{DCName} isn't in DC")

        else:
            index = ['B', 'C', 'D', 'E', 'F']  #存選手驗證資料欄位
            values = Veri.get_all_values()
            df = pd.DataFrame(values[0:], columns=values[0])
            end_row = df[df["Discord ID"].isin([""])].head(1).index.values[0]
            row = end_row + 1  #最後一欄
            #寫入隊伍資訊
            for i in range(0, 5):
                Veri.update_value(f'{index[i]}{row}',
                                  f'{item[i].value}')  # update the values

            await IsinDC.delete_roles(UnVerified)
            await IsinDC.add_roles(Verified)
            await ctx.send(f"{DCName} verify Success!")

    ##給定行數會自動去抓資料給定身分組
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def SubmitTeam(self, ctx, args):
        rng = TW.get_values(f'F{args}', f'M{args}',
                            returnas='range')  #抓取選手和經理名單
        rng2 = TW.get_values(f'B{args}', f'E{args}', returnas='range')  #抓隊伍資訊
        item = rng.cells[0]
        item2 = rng2.cells[0]

        #Part 1
        #創建隊伍名稱身分組
        await ctx.guild.create_role(
            name=item2[1].value,
            color=0x1abc9c,
            hoist=True,
        )
        await ctx.send(f"Create {item2[1].value} Role Success")

        #Part 2
        # 欄位相關資訊
        teamRegion = []
        index1 = ['D', 'E', 'F', 'G']  #存隊伍資訊欄位
        index2 = ['H', 'I', 'J', 'K', 'L', 'M', 'N', 'O']  #存選手資訊欄位
        values = Vaild.get_all_values()
        df = pd.DataFrame(values[0:], columns=values[0])
        end_row = df[df["Team Name"].isin([""])].head(1).index.values[0]
        row = end_row + 1  #最後一欄

        #寫入隊伍資訊
        for i in range(0, 4):
            Vaild.update_value(f'{index1[i]}{row}',
                               f'{item2[i].value}')  # update the values

        #寫入選手資訊
        for i in range(0, 8):
            playername = item[i].value.strip()
            if playername == "":
                await ctx.send("這格為空白")
                continue  #繼續進入下一圈
            #print("User Name: ", playername)
            IsinVeri = Veri.find(playername)  #取得Verification表單
            IsinDC = ctx.guild.get_member_named(playername)  #確認是否在SRC伺服器

            checker = False
            for j in range(len(IsinDC.roles)):
                if IsinDC.roles[j].name == data["Player"]:
                    await ctx.send(
                        f"{playername} was already in other team, please check Sheet Detail"
                    )
                    checker = True
                    break
                if IsinDC.roles[j].name == data["Manager"]:
                    await ctx.send(
                        f"{playername} was already in other team, please check Sheet Detail"
                    )
                    checker = True
                    break

            if checker == True:  #已有隊伍就跳出迴圈
                continue  #繼續進入下一圈

            if IsinDC == None:  #確認是否在SRC伺服器
                #print("Isn't in DC")
                await ctx.send(f"{playername} isn't in DC")
                Vaild.update_value(f'{index2[i]}{row}',
                                   f"{playername}(Red)")  # update the values
                continue  #繼續進入下一圈

            #是否有在Verification表單裡
            if len(IsinVeri) == 0:
                #print("Isn't in Verification Sheet")
                await ctx.send(f"{playername} isn't in Verification Sheet")
                Vaild.update_value(
                    f'{index2[i]}{row}',
                    f"{playername}(Yellow)")  # update the values
                continue  #繼續進入下一圈

            if IsinVeri[0].color != (0.8509804, 0.91764706, 0.827451, 0):
                #print("沒有驗證通過")
                await ctx.send(f"{playername} 沒有驗證通過")
                Vaild.update_value(
                    f'{index2[i]}{row}',
                    f"{playername}(Yellow)")  # update the values
                continue  #繼續進入下一圈

            else:  #符合資格

                Regionrow = f"F{IsinVeri[0].row}"  #GET ROW
                temp = Veri.get_values(f'{Regionrow}',
                                       f'{Regionrow}',
                                       returnas='range')  #抓取選手國家
                temp_item = temp.cells[0]
                teamRegion.append(temp_item[0].value)

                await ctx.send(f"{playername} Pass")

                Vaild.update_value(f'{index2[i]}{row}',
                                   f'{playername}')  # update the values
                role = discord.utils.get(ctx.guild.roles, name=item2[1].value)
                PlayerRole = discord.utils.get(ctx.guild.roles,
                                               name=data['Player'])
                ManageRole = discord.utils.get(ctx.guild.roles,
                                               name=data['Manager'])
                await IsinDC.add_roles(role)

                if i != 7:  #選手身分組
                    await IsinDC.add_roles(PlayerRole)

                else:  #經理身分組
                    await IsinDC.add_roles(ManageRole)

                await ctx.send(f"Add {item2[1].value} Role to {IsinDC} Success"
                               )

        maxlabel = max(teamRegion, key=teamRegion.count)
        #print(maxlabel)
        country = data[f'{maxlabel}']
        print(country)
        role = discord.utils.get(ctx.guild.roles, name=item2[1].value)
        await role.edit(name=f"[{country}]{item2[1].value}")  #更新身分組的國籍
        Vaild.update_value(f'C{row}', f'{country}')  # update the values

    ##設定Google Sheet ID
    ##給定行數會自動去抓資料給定身分組
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def SubmitTeamEn(self, ctx, args):
        rng = EN.get_values(f'F{args}', f'M{args}',
                            returnas='range')  #抓取選手和經理名單
        rng2 = EN.get_values(f'B{args}', f'E{args}', returnas='range')  #抓隊伍資訊
        item = rng.cells[0]
        item2 = rng2.cells[0]

        #Part 1
        #取得隊伍名稱
        await ctx.guild.create_role(name=item2[1].value,
                                    color=0X1abc9c,
                                    hoist=True)
        await ctx.send(f"Create {item2[1].value} Role Success")

        #Part 2
        # 欄位相關資訊
        teamRegion = []
        index1 = ['D', 'E', 'F', 'G']  #存隊伍資訊欄位
        index2 = ['H', 'I', 'J', 'K', 'L', 'M', 'N', 'O']  #存選手資訊欄位
        values = Vaild.get_all_values()
        df = pd.DataFrame(values[0:], columns=values[0])
        end_row = df[df["Team Name"].isin([""])].head(1).index.values[0]
        row = end_row + 1  #最後一欄

        #寫入隊伍資訊
        for i in range(0, 4):
            Vaild.update_value(f'{index1[i]}{row}',
                               f'{item2[i].value}')  # update the values

        #寫入選手資訊
        for i in range(0, 8):
            playername = item[i].value.strip()
            if playername == "":
                await ctx.send("這格為空白")
                continue  #繼續進入下一圈
            #print("User Name: ", playername)
            IsinVeri = Veri.find(playername)  #取得Verification表單
            IsinDC = ctx.guild.get_member_named(playername)  #確認是否在SRC伺服器

            checker = False
            for j in range(len(IsinDC.roles)):
                if IsinDC.roles[j].name == data["Player"]:
                    await ctx.send(
                        f"{playername} was already in other team, please check Sheet Detail"
                    )
                    checker = True
                    break
                if IsinDC.roles[j].name == data["Manager"]:
                    await ctx.send(
                        f"{playername} was already in other team, please check Sheet Detail"
                    )
                    checker = True
                    break

            if checker == True:  #已有隊伍就跳出迴圈
                continue  #繼續進入下一圈

            if IsinDC == None:  #確認是否在SRC伺服器
                await ctx.send(f"{playername} isn't in DC")
                Vaild.update_value(f'{index2[i]}{row}',
                                   f"{playername}(Red)")  # update the values
                continue  #繼續進入下一圈

            #是否有在Verification表單裡
            if len(IsinVeri) == 0:
                await ctx.send(f"{playername} isn't in Verification表單裡")
                Vaild.update_value(
                    f'{index2[i]}{row}',
                    f"{playername}(Yellow)")  # update the values
                continue  #繼續進入下一圈

            if IsinVeri[0].color != (0.8509804, 0.91764706, 0.827451, 0):
                await ctx.send(f"{playername} 沒有驗證通過")
                Vaild.update_value(
                    f'{index2[i]}{row}',
                    f"{playername}(Yellow)")  # update the values
                continue  #繼續進入下一圈

            else:  #符合資格

                Regionrow = f"F{IsinVeri[0].row}"  #GET ROW
                temp = Veri.get_values(f'{Regionrow}',
                                       f'{Regionrow}',
                                       returnas='range')  #抓取選手國家
                temp_item = temp.cells[0]
                teamRegion.append(temp_item[0].value)

                await ctx.send(f"{playername} Pass")
                Vaild.update_value(f'{index2[i]}{row}',
                                   f'{playername}')  # update the values
                role = discord.utils.get(ctx.guild.roles, name=item2[1].value)
                PlayerRole = discord.utils.get(ctx.guild.roles,
                                               name=data['Player'])
                ManageRole = discord.utils.get(ctx.guild.roles,
                                               name=data['Manager'])
                await IsinDC.add_roles(role)
                if i != 7:
                    await IsinDC.add_roles(PlayerRole)
                    await ctx.send(f"Add PlayerRole Role to {IsinDC} Success")
                else:
                    await IsinDC.add_roles(ManageRole)
                    await ctx.send(f"Add ManageRole Role to {IsinDC} Success")
                await ctx.send(f"Add {item2[1].value} Role to {IsinDC} Success"
                               )

        maxlabel = max(teamRegion, key=teamRegion.count)
        #print(maxlabel)
        country = data[f'{maxlabel}']
        print(country)
        role = discord.utils.get(ctx.guild.roles, name=item2[1].value)
        await role.edit(name=f"[{country}]{item2[1].value}")  #更新身分組的國籍

    ##設定Google Sheet ID
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def SetSheetID(self, ctx, args):
        API = pygsheets.authorize(service_file="API_Key.json")
        try:  ##測試連線
            test = API.open_by_url(
                f'https://docs.google.com/spreadsheets/d/{args}/edit?usp=sharing'
            )
            print(test.title)
        except:
            await ctx.send('Error!! Please check your sheetID')
            return

        with open('setting.json', 'rb') as f:  #定義成唯獨
            params = json.load(f)  #加載內容給 params
            params['sheetID'] = args  #填入ID
            await ctx.send(f'sheet change to {test.title}')
            dict = params  #將修改內容存入dict
        f.close()

        with open('setting.json', 'w') as r:
            json.dump(dict, r, indent=2)  #寫入Json裡
        r.close()

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def CheckSheet(self, ctx):
        await ctx.send(f"目前表單為 {WeekSignin.title}")

    ##Ban圖測試一版
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def BanMap(self, ctx):
        map_list = [
            'Clubhouse / 俱樂部會所', 'Bank / 銀行', 'Kafe Dostoyevksy / 杜斯妥也夫斯基咖啡館',
            'Oregon / 奧勒岡', 'Chalet / 木屋', 'Villa / 別墅', 'Border / 邊境',
            'Skyscraper / 摩天大樓', 'Theme Park / 主題樂園'
        ]

        map_listx = map_list
        await ctx.send("目前地圖池:")
        for index, value in enumerate(map_list):
            await ctx.send(f'{index+1}：{value}')

        #儲存要Ban的圖
        ban_list = []

        #接收User選項
        while len(ban_list) < 8:
            await ctx.send("Ban your map：")

            def check(m):
                return m.content == '1' or '2' or '3' and m.ctx == ctx and m.author != self.bot.user

            msg = await self.bot.wait_for('message', check=check)
            input_str = msg.content
            if len(input_str) > 0 and input_str.isdigit() and int(
                    input_str) in range(1, 10):
                if input_str not in ban_list:
                    ban_list.append(input_str)
                    mapnum = int(input_str)
                    await ctx.send(f"Your Team Ban Map: {map_list[mapnum - 1]}"
                                   )
                    continue
                else:
                    await ctx.send(
                        'The map has already banned choose another map')
            else:
                await ctx.send("There is no such map pick again")

        #刪除地圖池
        for i in sorted(ban_list, reverse=True):
            del map_listx[int(i) - 1]

        #比賽地圖
        await ctx.send(f"The chosen map is {map_listx[0]}")


async def setup(bot):
    await bot.add_cog(SRC(bot))

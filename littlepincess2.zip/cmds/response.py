import discord
from discord.ext import commands
from core.classes import Cog_Extension
import numpy as np
#import requests
#from bs4 import BeautifulSoup


class Response(Cog_Extension):

    ##用來確認response存活用
    @commands.command()
    async def responseisloaded(self, ctx):
        await ctx.send(f'Response is loaded!')

    @commands.Cog.listener()
    async def on_message(self, msg):

        # if msg.content.startswith('!map'):
        #     map_name = msg.content[5:]
        #     map_url = f'https://rainbowsix.fandom.com/wiki/{map_name}'
        #    response = requests.get(map_url)
        #     soup = BeautifulSoup(response.text, 'html.parser')
        #     image_url = soup.find('img',
        #                           {'class': 'pi-image-thumbnail'})['src']
        #     embed = discord.Embed(title=map_name.capitalize(), color=0x00ff00)
        #     embed.set_image(url=image_url)
        #     await msg.channel.send(embed=embed)

        if msg.guild.id != 1067281878471688282:

            if msg.author == self.bot.user:
                return

            if '跳樓' in msg.content:
                await msg.channel.send(f'''
                  ━━━━━┒咪醬等我
                  ┓┏┓┏┓┃我馬上陪妳
                  ┛┗┛┗┛┃＼😭／
                  ┓┏┓┏┓┃　/
                  ┛┗┛┗┛┃ノ)
                  ┓┏┓┏┓┃
                  ┛┗┛┗┛┃
                  ┓┏┓┏┓┃
                  ┛┗┛┗┛┃
                  ┻┻┻┻┻┻''')

            if '上吊' in msg.content:
                await msg.channel.send(
                    "https://media.discordapp.net/attachments/1078600119949213758/1089817689565954120/image.png?width=373&height=621"
                )

            if msg.content == '喔':
                await msg.channel.send("喔爽沒 可悲沒台詞")

            if msg.content == '是喔':
                await msg.channel.send("沒特別想得到你的肯定啦")

            if msg.content == '抽卡說明':
                await msg.channel.send('''
              小公主抽卡模擬器
              打 %抽卡 {輸入數字} 可以抽你想抽的數量
              
              機率說明:
                  UR    1%
                  SSR   5%
                  SR   40%
                  R    54%
              ''')

            if msg.content == '3分鐘':
                await msg.channel.send(
                    "https://media.discordapp.net/attachments/1081912384337215540/1085066291267772496/606e8e4a2b29c58e6f44ed7bbfa43702.gif?width=270&height=204"
                )

            if msg.content.startswith('打招呼'):
                channel = msg.channel

                await channel.send(f'說你好!')

                def check(m):
                    return m.content == '你好' and m.channel == channel

                msg = await self.bot.wait_for('message', check=check)

                await channel.send(f'你好 {msg.author.mention}!'.format(msg))

            if msg.content.startswith('占卜'):
                tmp = msg.content.split(" ", 2)
                luck = np.random.choice(['大吉', '吉', '小吉', '凶', '大凶'],
                                        size=1,
                                        p=[0.15, 0.3, 0.10, 0.3, 0.15])
                luck = str(luck).replace("['", "").replace("']", "")

                if len(tmp) == 1:
                    await msg.channel.send(f"{msg.author.mention} 要占卜什麼？")
                else:
                    await msg.channel.send(
                        f'{msg.author.mention} {tmp[1]}的運勢是 {luck}!!')


async def setup(bot):
    await bot.add_cog(Response(bot))

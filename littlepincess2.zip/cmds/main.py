import discord
from discord.ext import commands
from core.classes import Cog_Extension
import numpy as np
import random
import json

with open('setting.json', "r", encoding="utf8") as file:
    data = json.load(file)


class Main(Cog_Extension):

    #For Every Server
    @commands.command()
    async def ping(self, ctx):
        await ctx.send(f'機器人延遲{round(self.bot.latency * 1000)} 豪秒')

    @commands.command()
    async def 抽卡(self, ctx, args):
        if (int(args) > 10000):
            await ctx.send("抽卡數不要超過1萬啦 :(")
            return
        if (int(args) < 0):
            await ctx.send("小於0要怎麼抽卡 :(")
            return
        ur, sr, ssr, r = 0, 0, 0, 0

        for n in range(0, int(args)):
            card = random.choice(range(1, 101))
            if 1 <= card <= 54:
                r += 1
            if 55 <= card <= 94:
                sr += 1
            if 95 <= card <= 99:
                ssr += 1
            if card == 100:
                ur += 1

        result = '''抽了{a}張
本次抽卡狀況:
          {r}張        UR
          {q}張        SSR
          {w}張        SR
          {e}張        R
      '''
        result = result.format(a=args, r=ur, q=ssr, w=sr, e=r)
        await ctx.send(result)

    ##顯示延遲
    @commands.command()
    async def e04(self, ctx):
        await ctx.channel.purge(limit=1)
        await ctx.send(f'賣靠北 就他媽還沒下班')

    ##顯示EM頁面
    @commands.command()
    async def em(self, ctx):
        Embed = discord.Embed(title="小公主_BOT",
                              description="是一個可愛的坎特貝雷的小公主\n目前擁有指令如下",
                              color=0xf7ff8a)
        Embed.set_author(
            name="小公主",
            icon_url=
            "https://cdn.discordapp.com/attachments/759118803396984853/866698612208697354/6c12be5f091dbf1329436bafc73f47afd2ded3cf.jpg"
        )
        Embed.set_thumbnail(url="https://i.imgur.com/lyjRujt.gif")
        Embed.add_field(name="%ping", value="顯示機器人延遲", inline=False)
        Embed.add_field(name="%抽卡 {輸入數字}",
                        value="輸入 \"抽卡\" 和想要抽卡張數來測驗血統",
                        inline=True)
        Embed.add_field(name="抽卡說明", value="進行抽卡說明", inline=False)
        Embed.add_field(name="占卜",
                        value="輸入 \"占卜\" 空白後加一串連續文字可以占卜您的運勢",
                        inline=True)
        Embed.add_field(name="打招呼", value="你好~", inline=False)
        await ctx.send(embed=Embed)

    @commands.command(aliases=['c'])
    @commands.has_permissions(administrator=True)
    async def clean(self, ctx, num: int):
        await ctx.channel.purge(limit=num + 1)

    @commands.command()
    async def 抽獎(self, ctx, args):
        memberList = []
        for user in ctx.guild.members:
            if (user.bot == False):
                memberList.append(user.id)  ##取得現有伺服器全部人的名字
        for i in range(0, int(args)):
            winner = np.random.choice(memberList)  ##交給numpy抽獎
            memberList.remove(winner)  ##移除中獎人
            await ctx.send(f'恭喜 <@{winner}> 中獎')

    @commands.command()
    async def map(self, ctx):
        btn1 = discord.ui.Button(label="Villa / 別墅",
                                 style=discord.ButtonStyle.success,
                                 custom_id="Villa / 別墅")
        btn2 = discord.ui.Button(label="Bank / 銀行",
                                 style=discord.ButtonStyle.success,
                                 custom_id="Bank / 銀行")
        btn3 = discord.ui.Button(label="Border / 邊境",
                                 style=discord.ButtonStyle.success,
                                 custom_id="Border / 邊境")
        btn4 = discord.ui.Button(label="Oregon / 奧勒岡",
                                 style=discord.ButtonStyle.success,
                                 custom_id="Oregon / 奧勒岡")
        btn5 = discord.ui.Button(label="Chalet / 木屋",
                                 style=discord.ButtonStyle.success,
                                 custom_id="Chalet / 木屋")
        btn6 = discord.ui.Button(label="Kafe Dostoyevksy / 杜斯妥也夫斯基咖啡館",
                                 style=discord.ButtonStyle.success,
                                 custom_id="Kafe Dostoyevksy / 杜斯妥也夫斯基咖啡館")
        btn7 = discord.ui.Button(label="Theme Park / 主題樂園",
                                 style=discord.ButtonStyle.success,
                                 custom_id="Theme Park / 主題樂園")
        btn8 = discord.ui.Button(label="Skyscraper / 摩天大樓",
                                 style=discord.ButtonStyle.success,
                                 custom_id="Skyscraper / 摩天大樓")
        btn9 = discord.ui.Button(label="Club House / 俱樂部會所",
                                 style=discord.ButtonStyle.success,
                                 custom_id="Club House / 俱樂部會所")

        async def button_callback(interaction):
            await interaction.response.edit_message(
                content=f"{interaction.data['custom_id']}", view=None)

        btn1.callback = button_callback
        btn2.callback = button_callback
        btn3.callback = button_callback
        btn4.callback = button_callback
        btn5.callback = button_callback
        btn6.callback = button_callback
        btn7.callback = button_callback
        btn8.callback = button_callback
        btn9.callback = button_callback

        view = discord.ui.View()
        view.add_item(btn1)
        view.add_item(btn2)
        view.add_item(btn3)
        view.add_item(btn4)
        view.add_item(btn5)
        view.add_item(btn6)
        view.add_item(btn7)
        view.add_item(btn8)
        view.add_item(btn9)
        await ctx.send(view=view)


async def setup(bot):
    await bot.add_cog(Main(bot))
